import {describe,it,expect} from 'vitest';
const norm=x=>((x%360)+360)%360;
const signs=['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
const nak=l=>Math.floor(norm(l)/(360/27));
function d9(l){let s=Math.floor(norm(l)/30),p=Math.floor((norm(l)%30)/(30/9)),start=[0,9,6,3][s%4];return (start+p)%12}
describe('deterministic domain functions',()=>{it('normalizes longitude',()=>expect(norm(-1)).toBe(359));it('has 12 signs',()=>expect(signs).toHaveLength(12));it('maps 360 degrees to 27 nakshatras',()=>expect([...Array(1440)].map((_,i)=>nak(i/4))).toEqual(expect.any(Array)));it('keeps D9 in range',()=>{for(let i=0;i<1440;i++)expect(d9(i/4)).toBeGreaterThanOrEqual(0);});it('vimshottari years sum to 120',()=>expect([7,20,6,10,7,18,16,19,17].reduce((a,b)=>a+b,0)).toBe(120));});
