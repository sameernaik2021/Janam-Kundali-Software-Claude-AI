CREATE TABLE IF NOT EXISTS kundalis(
 id TEXT PRIMARY KEY,
 name TEXT,
 birth_date TEXT NOT NULL,
 birth_time TEXT NOT NULL,
 place TEXT,
 latitude REAL NOT NULL,
 longitude REAL NOT NULL,
 timezone TEXT NOT NULL,
 settings_json TEXT NOT NULL,
 result_json TEXT NOT NULL,
 calculation_version TEXT NOT NULL,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_kundalis_updated ON kundalis(updated_at DESC);
