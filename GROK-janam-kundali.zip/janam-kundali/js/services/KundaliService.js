/**
 * Application layer – orchestrates calculation engine
 */

import { dateToJD, localToUT } from '../calculations/julianDay.js';
import { getAyanamsa, toSidereal } from '../calculations/ayanamsa.js';
import { tropicalPositions, isRetrograde } from '../calculations/planets.js';
import { calculateAscendant } from '../calculations/ascendant.js';
import { wholeSignHouses, equalHouses, planetHouse } from '../calculations/houses.js';
import { getNakshatra, getRashi, formatDegree } from '../calculations/nakshatra.js';
import { calculateVimshottari, formatDuration } from '../calculations/dasha.js';
import { buildVarga } from '../calculations/divisionalCharts.js';
import { PLANETS, CALCULATION_VERSION } from '../config/constants.js';

/**
 * Generate complete Kundali from birth data
 * @param {Object} input
 * @returns {Object} KundaliResult
 */
export function generateKundali(input) {
  const {
    name = '',
    year, month, day,
    hour, minute, second = 0,
    latitude, longitude,
    timezone = 5.5,
    ayanamsaSystem = 'lahiri',
    houseSystem = 'whole'
  } = input;

  // 1. Julian Day (UT)
  const hourUT = localToUT(hour, minute, second, timezone);
  const jd = dateToJD(year, month, day, hourUT);

  // 2. Ayanāṃśa
  const ayanamsa = getAyanamsa(jd, ayanamsaSystem);

  // 3. Tropical positions
  const { longitudes: trop, speeds } = tropicalPositions(jd);

  // 4. Sidereal positions
  const sidereal = {};
  for (const [p, lon] of Object.entries(trop)) {
    sidereal[p] = toSidereal(lon, ayanamsa);
  }

  // 5. Lagna (tropical → sidereal)
  const tropAsc = calculateAscendant(jd, latitude, longitude);
  const lagnaLon = toSidereal(tropAsc, ayanamsa);
  const lagnaRashi = getRashi(lagnaLon);
  const lagnaNak = getNakshatra(lagnaLon);
  const lagnaDeg = formatDegree(lagnaLon);

  // 6. Houses
  const houses = houseSystem === 'equal'
    ? equalHouses(lagnaLon)
    : wholeSignHouses(lagnaLon);

  // 7. Planets enriched
  const planets = PLANETS.map(({ key, name, abbr, symbol }) => {
    const lon = sidereal[key];
    const rashi = getRashi(lon);
    const nak = getNakshatra(lon);
    const deg = formatDegree(lon);
    const house = planetHouse(lon, lagnaLon, houseSystem);
    const retro = isRetrograde(speeds[key] || 0);
    return {
      key, name, abbr, symbol,
      longitude: lon,
      rashi: rashi.nameEn,
      rashiSanskrit: rashi.name,
      rashiIndex: rashi.index,
      degree: deg.text,
      degInSign: lon % 30,
      house,
      nakshatra: nak.name,
      pada: nak.pada,
      nakLord: nak.lord,
      retrograde: retro,
      speed: speeds[key] || 0
    };
  });

  // 8. Moon details for summary
  const moon = planets.find(p => p.key === 'Moon');

  // 9. Dasha
  const birthDate = new Date(year, month - 1, day, hour, minute, second);
  const dashas = calculateVimshottari(sidereal.Moon, birthDate).map(d => ({
    ...d,
    durationText: formatDuration(d.years),
    startText: formatDate(d.start),
    endText: formatDate(d.end)
  }));

  // 10. Vargas
  const vargas = {
    D1: sidereal,
    D9: buildVarga(sidereal, 'D9'),
    D10: buildVarga(sidereal, 'D10')
  };

  return {
    meta: {
      name,
      calculationVersion: CALCULATION_VERSION,
      ayanamsaSystem,
      houseSystem,
      jd,
      ayanamsa: +ayanamsa.toFixed(4),
      generatedAt: new Date().toISOString()
    },
    birthData: {
      date: `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`,
      time: `${String(hour).padStart(2,'0')}:${String(minute).padStart(2,'0')}:${String(second).padStart(2,'0')}`,
      latitude, longitude, timezone
    },
    lagna: {
      longitude: lagnaLon,
      rashi: lagnaRashi.nameEn,
      rashiSanskrit: lagnaRashi.name,
      degree: lagnaDeg.text,
      nakshatra: lagnaNak.name,
      pada: lagnaNak.pada
    },
    moon: {
      rashi: moon.rashi,
      nakshatra: moon.nakshatra,
      pada: moon.pada
    },
    planets,
    houses,
    dashas,
    vargas,
    siderealLongitudes: sidereal
  };
}

function formatDate(d) {
  return d.toISOString().slice(0, 10);
}
