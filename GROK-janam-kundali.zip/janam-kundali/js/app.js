/**
 * Janam Kundali Application – entry point
 * Local-first, layered architecture
 */

import { CITIES } from './config/constants.js';
import { generateKundali } from './services/KundaliService.js';
import { initDatabase, saveKundali, getAllKundalis, getKundaliById, deleteKundali } from './storage/SQLiteDatabase.js';
import { renderNorthIndian, renderSouthIndian } from './ui/KundaliChart.js';

// ---------- State ----------
let currentKundali = null;
let chartStyle = 'north';
let currentVarga = 'D1';
let dbReady = false;

// ---------- DOM ----------
const $ = (sel) => document.querySelector(sel);
const form = $('#birth-form');
const results = $('#results');
const loading = $('#loading');
const formError = $('#form-error');

// ---------- Init ----------
async function init() {
  // Theme
  const savedTheme = localStorage.getItem('jk_theme') || 'dark';
  document.documentElement.setAttribute('data-theme', savedTheme);

  // Cities datalist
  const list = $('#city-list');
  CITIES.forEach(c => {
    const opt = document.createElement('option');
    opt.value = c.name;
    list.appendChild(opt);
  });

  // Place → lat/lon
  $('#place').addEventListener('change', () => {
    const city = CITIES.find(c => c.name === $('#place').value);
    if (city) {
      $('#latitude').value = city.lat;
      $('#longitude').value = city.lon;
      $('#timezone').value = city.tz;
    }
  });

  // Theme toggle
  $('#btn-theme').addEventListener('click', () => {
    const cur = document.documentElement.getAttribute('data-theme');
    const next = cur === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('jk_theme', next);
  });

  // Form
  form.addEventListener('submit', onGenerate);
  $('#btn-clear').addEventListener('click', () => {
    form.reset();
    $('#timezone').value = 5.5;
    results.hidden = true;
    currentKundali = null;
  });

  // Chart style
  $('#btn-chart-north').addEventListener('click', () => setChartStyle('north'));
  $('#btn-chart-south').addEventListener('click', () => setChartStyle('south'));

  // Varga tabs
  document.querySelectorAll('.varga-tabs .btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.varga-tabs .btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentVarga = btn.dataset.varga;
      renderVarga();
    });
  });

  // Actions
  $('#btn-save').addEventListener('click', onSave);
  $('#btn-print').addEventListener('click', () => window.print());
  $('#btn-export-json').addEventListener('click', onExport);

  // Drawer
  $('#btn-saved').addEventListener('click', openDrawer);
  $('#btn-close-drawer').addEventListener('click', closeDrawer);
  $('#drawer-overlay').addEventListener('click', closeDrawer);

  // DB
  try {
    await initDatabase();
    dbReady = true;
  } catch (e) {
    console.error('SQLite init failed', e);
  }

  // Default sample (Delhi)
  $('#dob').value = '1990-05-15';
  $('#tob').value = '10:30';
  $('#latitude').value = 28.6139;
  $('#longitude').value = 77.2090;
  $('#place').value = 'New Delhi';
}

function setChartStyle(style) {
  chartStyle = style;
  $('#btn-chart-north').classList.toggle('active', style === 'north');
  $('#btn-chart-south').classList.toggle('active', style === 'south');
  if (currentKundali) renderMainChart();
}

function onGenerate(e) {
  e.preventDefault();
  formError.hidden = true;

  const name = $('#name').value.trim();
  const dob = $('#dob').value;
  const tob = $('#tob').value;
  const lat = parseFloat($('#latitude').value);
  const lon = parseFloat($('#longitude').value);
  const tz = parseFloat($('#timezone').value) || 5.5;
  const ayanamsa = $('#ayanamsa').value;
  const houseSystem = $('#house-system').value;

  if (!dob || !tob || isNaN(lat) || isNaN(lon)) {
    showError('Please fill date, time, latitude and longitude.');
    return;
  }

  const [year, month, day] = dob.split('-').map(Number);
  const [hour, minute, second = 0] = tob.split(':').map(Number);

  loading.hidden = false;

  // Allow UI to update
  requestAnimationFrame(() => {
    try {
      currentKundali = generateKundali({
        name, year, month, day, hour, minute, second,
        latitude: lat, longitude: lon, timezone: tz,
        ayanamsaSystem: ayanamsa, houseSystem
      });
      renderAll();
      results.hidden = false;
      results.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (err) {
      console.error(err);
      showError('Calculation error: ' + err.message);
    } finally {
      loading.hidden = true;
    }
  });
}

function showError(msg) {
  formError.textContent = msg;
  formError.hidden = false;
}

function renderAll() {
  if (!currentKundali) return;
  const k = currentKundali;

  // Summary
  $('#sum-lagna').textContent = `${k.lagna.rashi} ${k.lagna.degree}`;
  $('#sum-rashi').textContent = k.moon.rashi;
  $('#sum-nakshatra').textContent = k.moon.nakshatra;
  $('#sum-pada').textContent = k.moon.pada;
  $('#sum-ayanamsa').textContent = k.meta.ayanamsa.toFixed(4) + '°';

  renderMainChart();
  renderPlanetTable();
  renderDasha();
  renderVarga();
}

function renderMainChart() {
  const el = $('#kundali-chart');
  if (chartStyle === 'south') {
    renderSouthIndian(el, currentKundali);
  } else {
    renderNorthIndian(el, currentKundali);
  }
}

function renderPlanetTable() {
  const tbody = $('#planet-tbody');
  tbody.innerHTML = currentKundali.planets.map(p => `
    <tr>
      <td>${p.symbol} ${p.name}</td>
      <td>${p.rashi}</td>
      <td>${p.degree}</td>
      <td>${p.house}</td>
      <td>${p.nakshatra}</td>
      <td>${p.pada}</td>
      <td class="${p.retrograde ? 'retro' : ''}">${p.retrograde ? 'R' : '—'}</td>
    </tr>
  `).join('');
}

function renderDasha() {
  const now = new Date();
  const timeline = $('#dasha-timeline');
  timeline.innerHTML = currentKundali.dashas.slice(0, 9).map(d => {
    const isCurrent = now >= d.start && now < d.end;
    return `<span class="dasha-chip ${isCurrent ? 'current' : ''}">${d.planet}</span>`;
  }).join('');

  const tbody = $('#dasha-tbody');
  tbody.innerHTML = currentKundali.dashas.slice(0, 12).map(d => `
    <tr>
      <td>${d.planet}${d.isPartial ? ' (balance)' : ''}</td>
      <td>${d.startText}</td>
      <td>${d.endText}</td>
      <td>${d.durationText}</td>
    </tr>
  `).join('');
}

function renderVarga() {
  const el = $('#varga-chart');
  const longs = currentKundali.vargas[currentVarga];
  if (chartStyle === 'south') {
    renderSouthIndian(el, currentKundali, longs);
  } else {
    renderNorthIndian(el, currentKundali, longs);
  }
}

async function onSave() {
  if (!currentKundali) return;
  if (!dbReady) {
    alert('Storage not ready');
    return;
  }
  try {
    const id = saveKundali(currentKundali);
    alert('Chart saved to your device (id: ' + id.slice(0, 8) + '…)');
  } catch (e) {
    alert('Save failed: ' + e.message);
  }
}

function onExport() {
  if (!currentKundali) return;
  const blob = new Blob([JSON.stringify(currentKundali, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `kundali-${currentKundali.birthData.date}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

function openDrawer() {
  if (!dbReady) return;
  const list = getAllKundalis();
  const el = $('#saved-list');
  if (!list.length) {
    el.innerHTML = '<p style="color:var(--text-muted);padding:1rem">No saved charts yet.</p>';
  } else {
    el.innerHTML = list.map(item => `
      <div class="saved-item" data-id="${item.id}">
        <div class="saved-item-name">${item.name || 'Unnamed'}</div>
        <div class="saved-item-meta">${item.birth_date} ${item.birth_time} · saved ${item.created_at.slice(0,10)}</div>
        <div class="saved-item-actions">
          <button type="button" class="btn btn-sm load-btn">Load</button>
          <button type="button" class="btn btn-sm del-btn">Delete</button>
        </div>
      </div>
    `).join('');
    el.querySelectorAll('.load-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.target.closest('.saved-item').dataset.id;
        const k = getKundaliById(id);
        if (k) {
          currentKundali = k;
          renderAll();
          results.hidden = false;
          closeDrawer();
        }
      });
    });
    el.querySelectorAll('.del-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.target.closest('.saved-item').dataset.id;
        if (confirm('Delete this chart?')) {
          deleteKundali(id);
          openDrawer(); // refresh
        }
      });
    });
  }
  $('#saved-drawer').hidden = false;
  $('#drawer-overlay').hidden = false;
}

function closeDrawer() {
  $('#saved-drawer').hidden = true;
  $('#drawer-overlay').hidden = true;
}

// Boot
init();
