/** Core Vedic constants */

export const RASHIS = [
  { id: 0, name: 'Meṣa', nameEn: 'Aries', lord: 'Mars', symbol: '♈' },
  { id: 1, name: 'Vṛṣabha', nameEn: 'Taurus', lord: 'Venus', symbol: '♉' },
  { id: 2, name: 'Mithuna', nameEn: 'Gemini', lord: 'Mercury', symbol: '♊' },
  { id: 3, name: 'Karkaṭa', nameEn: 'Cancer', lord: 'Moon', symbol: '♋' },
  { id: 4, name: 'Siṃha', nameEn: 'Leo', lord: 'Sun', symbol: '♌' },
  { id: 5, name: 'Kanyā', nameEn: 'Virgo', lord: 'Mercury', symbol: '♍' },
  { id: 6, name: 'Tulā', nameEn: 'Libra', lord: 'Venus', symbol: '♎' },
  { id: 7, name: 'Vṛścika', nameEn: 'Scorpio', lord: 'Mars', symbol: '♏' },
  { id: 8, name: 'Dhanu', nameEn: 'Sagittarius', lord: 'Jupiter', symbol: '♐' },
  { id: 9, name: 'Makara', nameEn: 'Capricorn', lord: 'Saturn', symbol: '♑' },
  { id: 10, name: 'Kumbha', nameEn: 'Aquarius', lord: 'Saturn', symbol: '♒' },
  { id: 11, name: 'Mīna', nameEn: 'Pisces', lord: 'Jupiter', symbol: '♓' }
];

export const NAKSHATRAS = [
  { id: 0, name: 'Aśvinī', lord: 'Ketu', deity: 'Aśvinī Kumāras' },
  { id: 1, name: 'Bharaṇī', lord: 'Venus', deity: 'Yama' },
  { id: 2, name: 'Kṛttikā', lord: 'Sun', deity: 'Agni' },
  { id: 3, name: 'Rohiṇī', lord: 'Moon', deity: 'Brahmā' },
  { id: 4, name: 'Mṛgaśīrṣa', lord: 'Mars', deity: 'Soma' },
  { id: 5, name: 'Ārdrā', lord: 'Rahu', deity: 'Rudra' },
  { id: 6, name: 'Punarvasu', lord: 'Jupiter', deity: 'Aditi' },
  { id: 7, name: 'Puṣya', lord: 'Saturn', deity: 'Bṛhaspati' },
  { id: 8, name: 'Āśleṣā', lord: 'Mercury', deity: 'Sarpa' },
  { id: 9, name: 'Maghā', lord: 'Ketu', deity: 'Pitṛs' },
  { id: 10, name: 'Pūrva Phalgunī', lord: 'Venus', deity: 'Bhaga' },
  { id: 11, name: 'Uttara Phalgunī', lord: 'Sun', deity: 'Aryaman' },
  { id: 12, name: 'Hasta', lord: 'Moon', deity: 'Savitṛ' },
  { id: 13, name: 'Citrā', lord: 'Mars', deity: 'Tvaṣṭṛ' },
  { id: 14, name: 'Svātī', lord: 'Rahu', deity: 'Vāyu' },
  { id: 15, name: 'Viśākhā', lord: 'Jupiter', deity: 'Indrāgni' },
  { id: 16, name: 'Anurādhā', lord: 'Saturn', deity: 'Mitra' },
  { id: 17, name: 'Jyeṣṭhā', lord: 'Mercury', deity: 'Indra' },
  { id: 18, name: 'Mūla', lord: 'Ketu', deity: 'Nirṛti' },
  { id: 19, name: 'Pūrvāṣāḍhā', lord: 'Venus', deity: 'Āpas' },
  { id: 20, name: 'Uttarāṣāḍhā', lord: 'Sun', deity: 'Viśvedevas' },
  { id: 21, name: 'Śravaṇa', lord: 'Moon', deity: 'Viṣṇu' },
  { id: 22, name: 'Dhaniṣṭhā', lord: 'Mars', deity: 'Vasus' },
  { id: 23, name: 'Śatabhiṣā', lord: 'Rahu', deity: 'Varuṇa' },
  { id: 24, name: 'Pūrva Bhādrapadā', lord: 'Jupiter', deity: 'Aja Ekapāda' },
  { id: 25, name: 'Uttara Bhādrapadā', lord: 'Saturn', deity: 'Ahir Budhnya' },
  { id: 26, name: 'Revatī', lord: 'Mercury', deity: 'Pūṣan' }
];

/** Vimśottarī sequence and years */
export const DASHA_SEQUENCE = ['Ketu', 'Venus', 'Sun', 'Moon', 'Mars', 'Rahu', 'Jupiter', 'Saturn', 'Mercury'];
export const DASHA_YEARS = {
  Ketu: 7, Venus: 20, Sun: 6, Moon: 10, Mars: 7,
  Rahu: 18, Jupiter: 16, Saturn: 19, Mercury: 17
};

export const PLANETS = [
  { key: 'Sun', name: 'Sūrya', abbr: 'Su', symbol: '☉' },
  { key: 'Moon', name: 'Candra', abbr: 'Mo', symbol: '☽' },
  { key: 'Mars', name: 'Maṅgala', abbr: 'Ma', symbol: '♂' },
  { key: 'Mercury', name: 'Budha', abbr: 'Me', symbol: '☿' },
  { key: 'Jupiter', name: 'Guru', abbr: 'Ju', symbol: '♃' },
  { key: 'Venus', name: 'Śukra', abbr: 'Ve', symbol: '♀' },
  { key: 'Saturn', name: 'Śani', abbr: 'Sa', symbol: '♄' },
  { key: 'Rahu', name: 'Rāhu', abbr: 'Ra', symbol: '☊' },
  { key: 'Ketu', name: 'Ketu', abbr: 'Ke', symbol: '☋' }
];

/** Common Indian cities for quick selection */
export const CITIES = [
  { name: 'New Delhi', lat: 28.6139, lon: 77.2090, tz: 5.5 },
  { name: 'Mumbai', lat: 19.0760, lon: 72.8777, tz: 5.5 },
  { name: 'Kolkata', lat: 22.5726, lon: 88.3639, tz: 5.5 },
  { name: 'Chennai', lat: 13.0827, lon: 80.2707, tz: 5.5 },
  { name: 'Bengaluru', lat: 12.9716, lon: 77.5946, tz: 5.5 },
  { name: 'Hyderabad', lat: 17.3850, lon: 78.4867, tz: 5.5 },
  { name: 'Pune', lat: 18.5204, lon: 73.8567, tz: 5.5 },
  { name: 'Ahmedabad', lat: 23.0225, lon: 72.5714, tz: 5.5 },
  { name: 'Jaipur', lat: 26.9124, lon: 75.7873, tz: 5.5 },
  { name: 'Lucknow', lat: 26.8467, lon: 80.9462, tz: 5.5 },
  { name: 'Varanasi', lat: 25.3176, lon: 82.9739, tz: 5.5 },
  { name: 'Patna', lat: 25.5941, lon: 85.1376, tz: 5.5 },
  { name: 'Bhopal', lat: 23.2599, lon: 77.4126, tz: 5.5 },
  { name: 'Chandigarh', lat: 30.7333, lon: 76.7794, tz: 5.5 },
  { name: 'Thiruvananthapuram', lat: 8.5241, lon: 76.9366, tz: 5.5 },
  { name: 'Guwahati', lat: 26.1445, lon: 91.7362, tz: 5.5 },
  { name: 'Srinagar', lat: 34.0837, lon: 74.7973, tz: 5.5 },
  { name: 'London', lat: 51.5074, lon: -0.1278, tz: 0 },
  { name: 'New York', lat: 40.7128, lon: -74.0060, tz: -5 },
  { name: 'Dubai', lat: 25.2048, lon: 55.2708, tz: 4 },
  { name: 'Singapore', lat: 1.3521, lon: 103.8198, tz: 8 },
  { name: 'Sydney', lat: -33.8688, lon: 151.2093, tz: 10 }
];

export const NAKSHATRA_SPAN = 360 / 27; // 13°20'
export const RASHI_SPAN = 30;
export const CALCULATION_VERSION = '1.0.0';
