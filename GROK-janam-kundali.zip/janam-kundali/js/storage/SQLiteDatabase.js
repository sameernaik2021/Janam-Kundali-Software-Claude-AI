/**
 * SQLite WASM persistence via sql.js + IndexedDB / localStorage fallback
 */

const DB_KEY = 'janam_kundali_sqlite';
let SQL = null;
let db = null;

export async function initDatabase() {
  if (db) return db;

  SQL = await initSqlJs({
    locateFile: file => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.3/${file}`
  });

  // Try restore from localStorage
  const saved = localStorage.getItem(DB_KEY);
  if (saved) {
    try {
      const u8 = Uint8Array.from(atob(saved), c => c.charCodeAt(0));
      db = new SQL.Database(u8);
    } catch (e) {
      console.warn('Could not restore DB, creating new', e);
      db = new SQL.Database();
    }
  } else {
    db = new SQL.Database();
  }

  // Schema
  db.run(`
    CREATE TABLE IF NOT EXISTS kundalis (
      id TEXT PRIMARY KEY,
      name TEXT,
      birth_date TEXT NOT NULL,
      birth_time TEXT NOT NULL,
      latitude REAL NOT NULL,
      longitude REAL NOT NULL,
      timezone REAL NOT NULL,
      ayanamsa TEXT,
      house_system TEXT,
      result_json TEXT NOT NULL,
      calculation_version TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    )
  `);

  persist();
  return db;
}

function persist() {
  if (!db) return;
  try {
    const data = db.export();
    const b64 = btoa(String.fromCharCode(...data));
    localStorage.setItem(DB_KEY, b64);
  } catch (e) {
    console.warn('Persist failed (quota?)', e);
  }
}

export function saveKundali(kundali) {
  if (!db) throw new Error('DB not initialized');
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  const name = kundali.meta.name || `Chart ${kundali.birthData.date}`;

  db.run(
    `INSERT INTO kundalis (id, name, birth_date, birth_time, latitude, longitude, timezone,
      ayanamsa, house_system, result_json, calculation_version, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      id,
      name,
      kundali.birthData.date,
      kundali.birthData.time,
      kundali.birthData.latitude,
      kundali.birthData.longitude,
      kundali.birthData.timezone,
      kundali.meta.ayanamsaSystem,
      kundali.meta.houseSystem,
      JSON.stringify(kundali),
      kundali.meta.calculationVersion,
      now,
      now
    ]
  );
  persist();
  return id;
}

export function getAllKundalis() {
  if (!db) return [];
  const res = db.exec('SELECT id, name, birth_date, birth_time, created_at FROM kundalis ORDER BY created_at DESC');
  if (!res.length) return [];
  const cols = res[0].columns;
  return res[0].values.map(row => {
    const obj = {};
    cols.forEach((c, i) => obj[c] = row[i]);
    return obj;
  });
}

export function getKundaliById(id) {
  if (!db) return null;
  const stmt = db.prepare('SELECT result_json FROM kundalis WHERE id = ?');
  stmt.bind([id]);
  if (stmt.step()) {
    const row = stmt.getAsObject();
    stmt.free();
    return JSON.parse(row.result_json);
  }
  stmt.free();
  return null;
}

export function deleteKundali(id) {
  if (!db) return;
  db.run('DELETE FROM kundalis WHERE id = ?', [id]);
  persist();
}
