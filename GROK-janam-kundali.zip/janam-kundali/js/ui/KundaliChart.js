/**
 * North Indian (diamond) & South Indian chart renderers
 */

import { RASHIS, PLANETS } from '../config/constants.js';

const PLANET_ABBR = Object.fromEntries(PLANETS.map(p => [p.key, p.abbr]));

/**
 * Render North Indian diamond chart as SVG
 * Houses fixed; signs rotate with Lagna at top.
 */
export function renderNorthIndian(container, kundali, vargaLongitudes = null) {
  const lagnaSign = Math.floor(kundali.lagna.longitude / 30) % 12;
  const longs = vargaLongitudes || kundali.siderealLongitudes;

  // Group planets by house (whole sign relative to lagna)
  const byHouse = Array.from({ length: 13 }, () => []);
  for (const [key, lon] of Object.entries(longs)) {
    const sign = Math.floor(lon / 30) % 12;
    const house = ((sign - lagnaSign + 12) % 12) + 1;
    const p = kundali.planets.find(x => x.key === key);
    byHouse[house].push({
      abbr: PLANET_ABBR[key] || key.slice(0, 2),
      retro: p ? p.retrograde : false
    });
  }

  // House geometry centres (viewBox 0 0 300 300)
  // House 1 top centre, then counter-clockwise
  const centres = {
    1:  [150, 55],
    2:  [75,  30],
    3:  [30,  75],
    4:  [55, 150],
    5:  [30, 225],
    6:  [75, 270],
    7:  [150,245],
    8:  [225,270],
    9:  [270,225],
    10: [245,150],
    11: [270, 75],
    12: [225, 30]
  };

  let svg = `<svg viewBox="0 0 300 300" xmlns="http://www.w3.org/2000/svg" aria-label="North Indian Kundali">
    <rect class="chart-bg" width="300" height="300" rx="4"/>
    <!-- Outer square -->
    <rect x="8" y="8" width="284" height="284" class="chart-line" rx="2"/>
    <!-- Diagonals -->
    <line x1="8" y1="8" x2="292" y2="292" class="chart-line"/>
    <line x1="292" y1="8" x2="8" y2="292" class="chart-line"/>
    <!-- Inner diamond -->
    <polygon points="150,8 292,150 150,292 8,150" class="chart-line"/>
  `;

  for (let h = 1; h <= 12; h++) {
    const signIdx = (lagnaSign + h - 1) % 12;
    const [cx, cy] = centres[h];
    const signNum = signIdx + 1;
    svg += `<text x="${cx}" y="${cy - 8}" text-anchor="middle" class="chart-sign">${signNum}</text>`;
    const planets = byHouse[h];
    if (planets.length) {
      const labels = planets.map(p => p.retro ? p.abbr + 'R' : p.abbr).join(' ');
      svg += `<text x="${cx}" y="${cy + 10}" text-anchor="middle" class="chart-planet ${planets.some(p=>p.retro)?'retro':''}">${labels}</text>`;
    }
    if (h === 1) {
      svg += `<text x="${cx}" y="${cy + 22}" text-anchor="middle" class="chart-lagna-marker">Asc</text>`;
    }
  }

  svg += '</svg>';
  container.innerHTML = svg;
}

/**
 * South Indian style – fixed signs, Lagna marked
 */
export function renderSouthIndian(container, kundali, vargaLongitudes = null) {
  const lagnaSign = Math.floor(kundali.lagna.longitude / 30) % 12;
  const longs = vargaLongitudes || kundali.siderealLongitudes;

  // South Indian layout: 4x4 grid, corners empty, signs fixed (Pisces top-left going clockwise or traditional)
  // Traditional South: signs fixed, Meena (Pisces) top-left, then clockwise or anti depending on school.
  // Common modern: 
  // Row0: Pi, Ar, Ta, Ge
  // Row1: Aq,     ,     , Cn
  // Row2: Cp,     ,     , Le
  // Row3: Sg, Sc, Li, Vi

  const gridSigns = [
    [11, 0, 1, 2],
    [10, -1, -1, 3],
    [9, -1, -1, 4],
    [8, 7, 6, 5]
  ];

  const bySign = Array.from({ length: 12 }, () => []);
  for (const [key, lon] of Object.entries(longs)) {
    const sign = Math.floor(lon / 30) % 12;
    const p = kundali.planets.find(x => x.key === key);
    bySign[sign].push({
      abbr: PLANET_ABBR[key] || key.slice(0, 2),
      retro: p ? p.retrograde : false
    });
  }

  let html = '<div class="south-grid">';
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      const s = gridSigns[r][c];
      if (s < 0) {
        html += '<div class="south-cell empty"></div>';
        continue;
      }
      const isLagna = s === lagnaSign;
      const planets = bySign[s];
      const pText = planets.map(p => p.retro ? `<span class="retro">${p.abbr}R</span>` : p.abbr).join(' ');
      html += `<div class="south-cell">
        <span class="south-sign">${RASHIS[s].nameEn.slice(0,3)}${isLagna ? ' ▲' : ''}</span>
        <div class="south-planets">${pText}</div>
      </div>`;
    }
  }
  html += '</div>';
  container.innerHTML = html;
}
