/**
 * Nakṣatra & Pada from sidereal longitude
 */

import { NAKSHATRAS, NAKSHATRA_SPAN } from '../config/constants.js';

/**
 * @param {number} lon  sidereal longitude 0–360
 * @returns {{ nakshatra, pada, degreeInNakshatra, lord }}
 */
export function getNakshatra(lon) {
  const n = Math.floor(lon / NAKSHATRA_SPAN) % 27;
  const degIn = lon % NAKSHATRA_SPAN;
  const pada = Math.floor(degIn / (NAKSHATRA_SPAN / 4)) + 1;
  const nak = NAKSHATRAS[n];
  return {
    index: n,
    name: nak.name,
    lord: nak.lord,
    deity: nak.deity,
    pada,
    degreeInNakshatra: degIn,
    spanStart: n * NAKSHATRA_SPAN,
    spanEnd: (n + 1) * NAKSHATRA_SPAN
  };
}

/**
 * Rāśi from longitude
 */
export function getRashi(lon) {
  const idx = Math.floor(lon / 30) % 12;
  return {
    index: idx,
    name: ['Meṣa','Vṛṣabha','Mithuna','Karkaṭa','Siṃha','Kanyā','Tulā','Vṛścika','Dhanu','Makara','Kumbha','Mīna'][idx],
    nameEn: ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'][idx]
  };
}

/**
 * Format degree as sign + d°m'
 */
export function formatDegree(lon) {
  const sign = Math.floor(lon / 30) % 12;
  const degInSign = lon % 30;
  const d = Math.floor(degInSign);
  const m = Math.floor((degInSign - d) * 60);
  const s = Math.round(((degInSign - d) * 60 - m) * 60);
  return { sign, deg: d, min: m, sec: s, text: `${d}° ${m.toString().padStart(2,'0')}'` };
}
