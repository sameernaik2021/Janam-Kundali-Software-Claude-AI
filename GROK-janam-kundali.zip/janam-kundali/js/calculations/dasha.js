/**
 * Vimśottarī Daśā calculation from Moon's Nakṣatra
 */

import { DASHA_SEQUENCE, DASHA_YEARS, NAKSHATRA_SPAN } from '../config/constants.js';
import { getNakshatra } from './nakshatra.js';
import { addYears } from './julianDay.js';

/**
 * Calculate full Mahādaśā timeline from birth
 * @param {number} moonLon  sidereal Moon longitude
 * @param {Date} birthDate  local birth Date object
 * @returns {Array<{planet, start, end, years, isPartial}>}
 */
export function calculateVimshottari(moonLon, birthDate) {
  const nak = getNakshatra(moonLon);
  const lord = nak.lord;
  const startIdx = DASHA_SEQUENCE.indexOf(lord);
  if (startIdx < 0) throw new Error('Unknown nakshatra lord: ' + lord);

  // Balance of first dasha
  const remainingFraction = (nak.spanEnd - moonLon) / NAKSHATRA_SPAN;
  const firstYears = DASHA_YEARS[lord] * remainingFraction;

  const timeline = [];
  let current = new Date(birthDate.getTime());

  // First (partial) period
  const firstEnd = addYears(current, firstYears);
  timeline.push({
    planet: lord,
    start: new Date(current.getTime()),
    end: firstEnd,
    years: firstYears,
    isPartial: true
  });
  current = firstEnd;

  // Subsequent full periods (cover at least 120 years)
  let idx = startIdx;
  let totalYears = firstYears;
  while (totalYears < 120) {
    idx = (idx + 1) % 9;
    const planet = DASHA_SEQUENCE[idx];
    const yrs = DASHA_YEARS[planet];
    const end = addYears(current, yrs);
    timeline.push({
      planet,
      start: new Date(current.getTime()),
      end,
      years: yrs,
      isPartial: false
    });
    current = end;
    totalYears += yrs;
  }

  return timeline;
}

/**
 * Format duration years → "Yy Mm Dd"
 */
export function formatDuration(years) {
  const y = Math.floor(years);
  const rem = (years - y) * 12;
  const m = Math.floor(rem);
  const d = Math.round((rem - m) * 30.4375);
  return `${y}y ${m}m ${d}d`;
}
