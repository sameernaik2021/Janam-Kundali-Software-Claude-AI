/**
 * Ayanāṃśa calculations
 * Lahiri (Chitrapaksha) is the Indian national standard.
 */

/**
 * Lahiri ayanāṃśa for a given Julian Day.
 * Polynomial approximation around J2000 (validated ~0.01° for 1900–2100).
 * Source: Indian Astronomical Ephemeris / common Meeus-style fit.
 * @param {number} jd
 * @returns {number} degrees
 */
export function lahiriAyanamsa(jd) {
  const T = (jd - 2451545.0) / 36525.0; // centuries from J2000.0
  // 23.85306 + 1.39722*T + 0.00018*T²  (degrees)
  return 23.85306 + 1.39722 * T + 0.00018 * T * T;
}

/**
 * Raman ayanāṃśa (approximate offset from Lahiri)
 */
export function ramanAyanamsa(jd) {
  return lahiriAyanamsa(jd) - 1.45; // approx difference
}

/**
 * KP (Newcomb) ayanāṃśa approximate
 */
export function kpAyanamsa(jd) {
  return lahiriAyanamsa(jd) - 0.09;
}

/**
 * Get ayanāṃśa by system name
 */
export function getAyanamsa(jd, system = 'lahiri') {
  switch (system) {
    case 'raman': return ramanAyanamsa(jd);
    case 'kp': return kpAyanamsa(jd);
    case 'lahiri':
    default: return lahiriAyanamsa(jd);
  }
}

/**
 * Convert tropical longitude → sidereal
 */
export function toSidereal(tropicalLon, ayanamsa) {
  let sid = tropicalLon - ayanamsa;
  while (sid < 0) sid += 360;
  while (sid >= 360) sid -= 360;
  return sid;
}
