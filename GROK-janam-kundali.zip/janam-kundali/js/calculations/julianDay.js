/**
 * Julian Day Number utilities (Meeus, Astronomical Algorithms Ch.7)
 */

/**
 * Convert Gregorian (or Julian) date/time to Julian Day Number.
 * @param {number} year
 * @param {number} month 1-12
 * @param {number} day
 * @param {number} hourUT  fractional hours in UT
 * @returns {number} JD
 */
export function dateToJD(year, month, day, hourUT = 0) {
  let y = year;
  let m = month;
  if (m <= 2) {
    y -= 1;
    m += 12;
  }
  const A = Math.floor(y / 100);
  const B = 2 - A + Math.floor(A / 4); // Gregorian
  const jd =
    Math.floor(365.25 * (y + 4716)) +
    Math.floor(30.6001 * (m + 1)) +
    day +
    hourUT / 24 +
    B -
    1524.5;
  return jd;
}

/**
 * Local civil time → UT hours given timezone offset in hours (east positive).
 */
export function localToUT(hour, minute, second, tzHours) {
  const local = hour + minute / 60 + second / 3600;
  return local - tzHours;
}

/**
 * JD to calendar date (approximate, for display)
 */
export function jdToDate(jd) {
  const z = Math.floor(jd + 0.5);
  const f = jd + 0.5 - z;
  let A = z;
  if (z >= 2299161) {
    const alpha = Math.floor((z - 1867216.25) / 36524.25);
    A = z + 1 + alpha - Math.floor(alpha / 4);
  }
  const B = A + 1524;
  const C = Math.floor((B - 122.1) / 365.25);
  const D = Math.floor(365.25 * C);
  const E = Math.floor((B - D) / 30.6001);
  const day = B - D - Math.floor(30.6001 * E) + f;
  const month = E < 14 ? E - 1 : E - 13;
  const year = month > 2 ? C - 4716 : C - 4715;
  const dayInt = Math.floor(day);
  const frac = day - dayInt;
  const hours = frac * 24;
  const h = Math.floor(hours);
  const min = Math.floor((hours - h) * 60);
  const sec = Math.round(((hours - h) * 60 - min) * 60);
  return { year, month, day: dayInt, hour: h, minute: min, second: sec };
}

/**
 * Add fractional years to a Date (for Dasha end dates)
 */
export function addYears(date, years) {
  const d = new Date(date.getTime());
  const days = years * 365.2425;
  d.setTime(d.getTime() + days * 86400000);
  return d;
}
