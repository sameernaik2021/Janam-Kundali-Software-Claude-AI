/**
 * Lagna (Ascendant) calculation
 * Uses local sidereal time and ecliptic-horizon intersection (Meeus style).
 */

const DEG = Math.PI / 180;
const RAD = 180 / Math.PI;

function norm360(x) {
  x %= 360;
  if (x < 0) x += 360;
  return x;
}

/**
 * Mean obliquity of the ecliptic (Meeus)
 */
function obliquity(jd) {
  const T = (jd - 2451545.0) / 36525.0;
  const eps =
    23.439291 -
    0.0130042 * T -
    0.00000016 * T * T +
    0.000000504 * T * T * T;
  return eps;
}

/**
 * Greenwich Mean Sidereal Time in degrees
 */
function gmst(jd) {
  const T = (jd - 2451545.0) / 36525.0;
  let st =
    280.46061837 +
    360.98564736629 * (jd - 2451545.0) +
    0.000387933 * T * T -
    (T * T * T) / 38710000;
  return norm360(st);
}

/**
 * Calculate Ascendant (tropical) in degrees
 * @param {number} jd  Julian Day (UT)
 * @param {number} lat  geographic latitude degrees
 * @param {number} lon  geographic longitude degrees (east +)
 * @returns {number} tropical ascendant longitude
 */
export function calculateAscendant(jd, lat, lon) {
  const lst = norm360(gmst(jd) + lon); // Local sidereal time in degrees
  const eps = obliquity(jd) * DEG;
  const latR = lat * DEG;
  const lstR = lst * DEG;

  // RAMC = LST
  const y = Math.cos(lstR);
  const x = -Math.sin(lstR) * Math.cos(eps) - Math.tan(latR) * Math.sin(eps);
  let asc = Math.atan2(y, x) * RAD;
  asc = norm360(asc);
  return asc;
}
