/**
 * House (Bhāva) calculations – Whole Sign & Equal
 */

import { RASHIS } from '../config/constants.js';

function norm360(x) {
  x %= 360;
  if (x < 0) x += 360;
  return x;
}

/**
 * Whole-sign houses: house 1 = sign of Lagna, then sequential.
 * @param {number} lagnaLon  sidereal longitude of Lagna
 * @returns {Array<{house:number, sign:number, signName:string, cusp:number}>}
 */
export function wholeSignHouses(lagnaLon) {
  const lagnaSign = Math.floor(lagnaLon / 30) % 12;
  const houses = [];
  for (let h = 1; h <= 12; h++) {
    const sign = (lagnaSign + h - 1) % 12;
    houses.push({
      house: h,
      sign,
      signName: RASHIS[sign].nameEn,
      signSanskrit: RASHIS[sign].name,
      cusp: sign * 30 // whole-sign cusp at 0° of the sign
    });
  }
  return houses;
}

/**
 * Equal house system: cusps every 30° from Lagna degree
 */
export function equalHouses(lagnaLon) {
  const houses = [];
  for (let h = 1; h <= 12; h++) {
    const cusp = norm360(lagnaLon + (h - 1) * 30);
    const sign = Math.floor(cusp / 30) % 12;
    houses.push({
      house: h,
      sign,
      signName: RASHIS[sign].nameEn,
      signSanskrit: RASHIS[sign].name,
      cusp
    });
  }
  return houses;
}

/**
 * Determine house number of a planet given lagna and house system
 */
export function planetHouse(planetLon, lagnaLon, system = 'whole') {
  if (system === 'whole') {
    const lagnaSign = Math.floor(lagnaLon / 30) % 12;
    const planetSign = Math.floor(planetLon / 30) % 12;
    return ((planetSign - lagnaSign + 12) % 12) + 1;
  }
  // Equal
  let diff = norm360(planetLon - lagnaLon);
  return Math.floor(diff / 30) + 1;
}
