/**
 * Varga (divisional) chart calculations
 * D1 = Rāśi (identity), D9 = Navāṃśa, D10 = Daśāṃśa
 */

function norm360(x) {
  x %= 360;
  if (x < 0) x += 360;
  return x;
}

/**
 * Generic varga: divide each sign into n equal parts
 * and map according to traditional rules.
 */
function vargaLongitude(lon, n, mappingFn) {
  const sign = Math.floor(lon / 30);
  const degInSign = lon % 30;
  const part = Math.floor(degInSign / (30 / n));
  const newSign = mappingFn(sign, part, n);
  const newDeg = (degInSign % (30 / n)) * n;
  return norm360(newSign * 30 + newDeg);
}

/** D9 Navāṃśa – each sign → 9 parts of 3°20' */
export function navamsa(lon) {
  // Standard: movable signs start from itself, fixed from 9th, dual from 5th
  return vargaLongitude(lon, 9, (sign, part) => {
    const base = sign % 3 === 0 ? sign :           // movable
                 sign % 3 === 1 ? (sign + 8) % 12 : // fixed
                                  (sign + 4) % 12;  // dual
    return (base + part) % 12;
  });
}

/** D10 Daśāṃśa – each sign → 10 parts of 3° */
export function dasamsa(lon) {
  return vargaLongitude(lon, 10, (sign, part) => {
    // Odd signs start from itself, even from 9th
    const base = sign % 2 === 0 ? sign : (sign + 8) % 12;
    return (base + part) % 12;
  });
}

/**
 * Build a simple varga chart object (planet longitudes in the varga)
 * @param {Object} siderealLongitudes  {Sun: lon, Moon: lon, ...}
 * @param {string} varga  'D1'|'D9'|'D10'
 */
export function buildVarga(siderealLongitudes, varga = 'D1') {
  const transform = {
    D1: (l) => l,
    D9: navamsa,
    D10: dasamsa
  }[varga] || ((l) => l);

  const result = {};
  for (const [planet, lon] of Object.entries(siderealLongitudes)) {
    result[planet] = transform(lon);
  }
  return result;
}
